package com.cuatroa.retotres.repository;

import com.cuatroa.retotres.model.User;
import com.cuatroa.retotres.repository.crud.UserCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * @author  Olga Patricia Bernal
 * @version 1.0
 * @since   2021-12-14
 */
@Repository
/**
 * Clase para UserRepository
 */
public class UserRepository {

    @Autowired
    /**
    * Gestionar todas las operaciones a partir de una tabla de base de datos
    */
    private UserCrudRepository userCrudRepository;
    /**
     * Hacer llamados get
     */
    public List<User> getAll() {
        return (List<User>) userCrudRepository.findAll();
    }
    /**
     * Hacer llamados get por Id
     */
    public Optional<User> getUser(int id) {
        return userCrudRepository.findById(id);
    }
     /*
     * peticion new (POST)
     */
    public User create(User user) {
        return userCrudRepository.save(user);
    }
    /**
     * peticion update para actualizar (PUT)
     */
    public void update(User user) {
        userCrudRepository.save(user);
    }
    /**
     * peticion update para borrar (DELETE)
     */
    public void delete(User user) {
        userCrudRepository.delete(user);
    }
    /**
     * clase verificar email
     */
    public boolean emailExists(String email) {
        Optional<User> usuario = userCrudRepository.findByEmail(email);
        
        return !usuario.isEmpty();
    }
    /**
     * Clase autenticar usuario
     */
    public Optional<User> authenticateUser(String email, String password) {
        return userCrudRepository.findByEmailAndPassword(email, password);
    }
    /**
     * Clase consultar por lastUserId
     */
    public Optional<User> lastUserId(){
        return userCrudRepository.findTopByOrderByIdDesc();
    }
    /**
     * Clase consultar por monthBirthtDay
     */
    public List<User> birthtDayList(String monthBirthtDay) {
        return userCrudRepository.findByMonthBirthtDay(monthBirthtDay);
    }
}
